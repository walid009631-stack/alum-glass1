import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

late SharedPreferences prefs;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  prefs = await SharedPreferences.getInstance();
  runApp(const App());
}

// ---------- الإعدادات (كلها قابلة للتعديل) ----------
const Map<String, List<dynamic>> settingDefs = {
  'win_kaab_mm': ['الشباك: ناقص من العرض للكعب (ملم)', 20.5],
  'win_h': ['الشباك: ناقص من الارتفاع للمسكة+الشنكل (سم)', 4.0],
  'win_gw': ['الشباك: زائد على الكعب لعرض الزجاج (سم)', 1.5],
  'win_gl': ['الشباك: ناقص من طول الدرفة لطول الزجاج (سم)', 10.6],
  'door_kaab': ['الباب: ناقص من العرض للكعب (سم)', 3.6],
  'door_h': ['الباب: ناقص من الارتفاع للمسكة+الشنكل (سم)', 2.8],
  'door_gw': ['الباب: ناقص من الكعب لعرض الزجاج (سم)', 11.5],
  'door_gl': ['الباب: ناقص من طول الباب لطول الزجاج (سم)', 15.0],
  'disc': ['سماكة الديسك (ملم)', 4.0],
  'bar_len': ['طول القضيب الخام (سم)', 600.0],
  'panel_w': ['عرض اللوح الخام (سم)', 122.0],
  'panel_h': ['طول اللوح الخام (سم)', 244.0],
};

double setting(String k) => prefs.getDouble('s_$k') ?? (settingDefs[k]![1] as double);

String f(double v) {
  var s = v.toStringAsFixed(2);
  if (s.contains('.')) {
    s = s.replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '');
  }
  return s;
}

double? num_(String s) => double.tryParse(s.trim().replaceAll(',', '.'));

const Color gold = Color(0xFFFFC107);
const Color navy = Color(0xFF0D2A4A);

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WD Alu Glass',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: navy),
      ),
      builder: (c, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const Home(),
    );
  }
}

// ---------- الواجهة الرئيسية ----------
class Home extends StatelessWidget {
  const Home({super.key});

  Widget tile(BuildContext c, String title, IconData icon, Color color, Widget page) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: Material(
          color: color,
          borderRadius: BorderRadius.circular(18),
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => page)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 52, color: Colors.white),
                const SizedBox(height: 8),
                Text(title,
                    style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 14),
              color: navy,
              child: Column(
                children: [
                  const Text('WD Alu Glass',
                      style: TextStyle(color: gold, fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: 1)),
                  const SizedBox(height: 2),
                  const Text('Walid', style: TextStyle(color: Colors.white, fontSize: 18)),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Column(
                  children: [
                    Expanded(
                      child: Row(children: [
                        tile(context, 'الشبابيك', Icons.window, const Color(0xFF1565C0), const ItemsPage(kind: 'win')),
                        tile(context, 'الباب', Icons.door_front_door, const Color(0xFF2E7D32), const ItemsPage(kind: 'door')),
                      ]),
                    ),
                    Expanded(
                      child: Row(children: [
                        tile(context, 'حساب الألواح', Icons.grid_view, const Color(0xFF6A1B9A), const PanelsPage()),
                        tile(context, 'حساب القضبان', Icons.straighten, const Color(0xFFEF6C00), const BarsPage()),
                      ]),
                    ),
                  ],
                ),
              ),
            ),
            TextButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage())),
              icon: const Icon(Icons.settings),
              label: const Text('إعدادات الخصميات'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------- حوار إدخال أرقام ----------
Future<List<double>?> askNums(BuildContext c, String title, List<String> labels, [List<double>? initial]) {
  final ctrls = List.generate(
      labels.length, (i) => TextEditingController(text: initial != null ? f(initial[i]) : ''));
  return showDialog<List<double>>(
    context: c,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (int i = 0; i < labels.length; i++)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: TextField(
                  controller: ctrls[i],
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(labelText: labels[i], border: const OutlineInputBorder()),
                ),
              ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(
          onPressed: () {
            final r = ctrls.map((e) => num_(e.text)).toList();
            if (r.any((e) => e == null || e <= 0)) return;
            Navigator.pop(ctx, r.cast<double>());
          },
          child: const Text('حفظ'),
        ),
      ],
    ),
  );
}

// ---------- الشبابيك والباب ----------
class ItemsPage extends StatefulWidget {
  final String kind;
  const ItemsPage({super.key, required this.kind});
  @override
  State<ItemsPage> createState() => _ItemsPageState();
}

class _ItemsPageState extends State<ItemsPage> {
  List<List<double>> items = []; // [عرض, ارتفاع, عدد]
  bool get isWin => widget.kind == 'win';
  String get key => 'items_${widget.kind}';

  @override
  void initState() {
    super.initState();
    final s = prefs.getString(key);
    if (s != null) {
      items = (jsonDecode(s) as List).map((e) => (e as List).map((x) => (x as num).toDouble()).toList()).toList();
    }
  }

  void save() => prefs.setString(key, jsonEncode(items));

  Map<String, double> calc(List<double> it) {
    final w = it[0], h = it[1];
    if (isWin) {
      final kaab = (w - setting('win_kaab_mm') / 10) / 2;
      final masika = h - setting('win_h');
      return {'kaab': kaab, 'masika': masika, 'gw': kaab + setting('win_gw'), 'gl': masika - setting('win_gl')};
    } else {
      final kaab = w - setting('door_kaab');
      final masika = h - setting('door_h');
      return {'kaab': kaab, 'masika': masika, 'gw': kaab - setting('door_gw'), 'gl': h - setting('door_gl')};
    }
  }

  Future<void> edit(int? i) async {
    final r = await askNums(context, i == null ? 'إضافة' : 'تعديل', ['العرض (سم)', 'الارتفاع (سم)', 'العدد'],
        i == null ? [100, 100, 1] : items[i]);
    if (r == null) return;
    setState(() {
      if (i == null) {
        items.add(r);
      } else {
        items[i] = r;
      }
    });
    save();
  }

  @override
  Widget build(BuildContext context) {
    double totalArea = 0, totalGlass = 0;
    int totalCount = 0;
    for (final it in items) {
      final c = calc(it);
      totalArea += it[0] * it[1] / 10000 * it[2];
      totalGlass += c['gw']! * c['gl']! / 10000 * it[2] * (isWin ? 2 : 1);
      totalCount += it[2].round();
    }
    final name = isWin ? 'شباك' : 'باب';
    return Scaffold(
      appBar: AppBar(title: Text(isWin ? 'الشبابيك' : 'الأبواب'), backgroundColor: navy, foregroundColor: Colors.white),
      floatingActionButton: FloatingActionButton.extended(
          onPressed: () => edit(null), icon: const Icon(Icons.add), label: Text('إضافة $name')),
      body: Column(
        children: [
          Expanded(
            child: items.isEmpty
                ? Center(child: Text('اضغط إضافة $name'))
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(8, 8, 8, 90),
                    itemCount: items.length,
                    itemBuilder: (c, i) {
                      final it = items[i];
                      final r = calc(it);
                      return Card(
                        child: ListTile(
                          onTap: () => edit(i),
                          title: Text('$name ${i + 1}:  ${f(it[0])} × ${f(it[1])}   (عدد ${f(it[2])})',
                              style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text(
                              'الكعب: ${f(r['kaab']!)}\nالمسكة+الشنكل: ${f(r['masika']!)}\n'
                              'الزجاج: ${f(r['gw']!)} × ${f(r['gl']!)}\n'
                              'المساحة: ${f(it[0] * it[1] / 10000 * it[2])} م²'),
                          isThreeLine: true,
                          trailing: IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () {
                                setState(() => items.removeAt(i));
                                save();
                              }),
                        ),
                      );
                    }),
          ),
          Container(
            width: double.infinity,
            color: navy,
            padding: const EdgeInsets.all(12),
            child: Text('العدد: $totalCount   |   المساحة: ${f(totalArea)} م²   |   الزجاج: ${f(totalGlass)} م²',
                textAlign: TextAlign.center, style: const TextStyle(color: gold, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}

// ---------- حساب القضبان ----------
class BarsPage extends StatefulWidget {
  const BarsPage({super.key});
  @override
  State<BarsPage> createState() => _BarsPageState();
}

class _BarsPageState extends State<BarsPage> {
  List<List<double>> pieces = []; // [طول, عدد]

  @override
  void initState() {
    super.initState();
    final s = prefs.getString('pieces_bars');
    if (s != null) {
      pieces = (jsonDecode(s) as List).map((e) => (e as List).map((x) => (x as num).toDouble()).toList()).toList();
    }
  }

  void save() => prefs.setString('pieces_bars', jsonEncode(pieces));

  Future<void> edit(int? i) async {
    final r = await askNums(context, 'قطعة', ['الطول (سم)', 'العدد'], i == null ? [100, 1] : pieces[i]);
    if (r == null) return;
    setState(() {
      if (i == null) {
        pieces.add(r);
      } else {
        pieces[i] = r;
      }
    });
    save();
  }

  @override
  Widget build(BuildContext context) {
    final barLen = setting('bar_len');
    final kerf = setting('disc') / 10;
    final all = <double>[];
    String? err;
    for (final p in pieces) {
      if (p[0] > barLen) err = 'قطعة طولها ${f(p[0])} أطول من القضيب';
      for (int k = 0; k < p[1].round(); k++) {
        all.add(p[0]);
      }
    }
    all.sort((a, b) => b.compareTo(a));
    final bars = <List<double>>[];
    final rem = <double>[];
    if (err == null) {
      for (final len in all) {
        int idx = -1;
        for (int b = 0; b < bars.length; b++) {
          if (rem[b] >= len) {
            idx = b;
            break;
          }
        }
        if (idx == -1) {
          bars.add([]);
          rem.add(barLen);
          idx = bars.length - 1;
        }
        bars[idx].add(len);
        rem[idx] = (rem[idx] - len - kerf).clamp(0, double.infinity).toDouble();
      }
    }
    final totalWaste = rem.fold<double>(0, (a, b) => a + b);
    return Scaffold(
      appBar: AppBar(title: const Text('حساب القضبان'), backgroundColor: navy, foregroundColor: Colors.white),
      floatingActionButton:
          FloatingActionButton.extended(onPressed: () => edit(null), icon: const Icon(Icons.add), label: const Text('إضافة قطعة')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 90),
        children: [
          Text('طول القضيب: ${f(barLen)} سم  |  الديسك: ${f(setting('disc'))} ملم', textAlign: TextAlign.center),
          const SizedBox(height: 6),
          for (int i = 0; i < pieces.length; i++)
            Card(
              child: ListTile(
                onTap: () => edit(i),
                title: Text('${f(pieces[i][0])} سم  ×  ${f(pieces[i][1])}'),
                trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () {
                      setState(() => pieces.removeAt(i));
                      save();
                    }),
              ),
            ),
          if (err != null) Text(err, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          if (err == null && bars.isNotEmpty) ...[
            const Divider(),
            Text('عدد القضبان: ${bars.length}   |   مجموع الهدر: ${f(totalWaste)} سم',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            for (int b = 0; b < bars.length; b++)
              Card(
                color: Colors.orange.shade50,
                child: ListTile(
                  title: Text('قضيب ${b + 1}: ${bars[b].map(f).join(' + ')}'),
                  subtitle: Text('الهدر: ${f(rem[b])} سم'),
                ),
              ),
          ],
        ],
      ),
    );
  }
}

// ---------- حساب الألواح ----------
class PanelsPage extends StatefulWidget {
  const PanelsPage({super.key});
  @override
  State<PanelsPage> createState() => _PanelsPageState();
}

class _PanelsPageState extends State<PanelsPage> {
  List<List<double>> pieces = []; // [عرض, طول, عدد]

  @override
  void initState() {
    super.initState();
    final s = prefs.getString('pieces_panels');
    if (s != null) {
      pieces = (jsonDecode(s) as List).map((e) => (e as List).map((x) => (x as num).toDouble()).toList()).toList();
    }
  }

  void save() => prefs.setString('pieces_panels', jsonEncode(pieces));

  Future<void> edit(int? i) async {
    final r = await askNums(context, 'قطعة', ['العرض (سم)', 'الطول (سم)', 'العدد'], i == null ? [50, 50, 1] : pieces[i]);
    if (r == null) return;
    setState(() {
      if (i == null) {
        pieces.add(r);
      } else {
        pieces[i] = r;
      }
    });
    save();
  }

  @override
  Widget build(BuildContext context) {
    final sw = setting('panel_w'), sh = setting('panel_h'), kerf = setting('disc') / 10;
    String? err;
    final all = <List<double>>[];
    for (final p in pieces) {
      if (p[0] > sw || p[1] > sh) err = 'قطعة ${f(p[0])}×${f(p[1])} أكبر من اللوح';
      for (int k = 0; k < p[2].round(); k++) {
        all.add([p[0], p[1]]);
      }
    }
    all.sort((a, b) => b[1].compareTo(a[1]));
    // كل لوح: قائمة رفوف [y, ارتفاع الرف, العرض المستعمل]
    final sheets = <List<List<double>>>[];
    final counts = <int>[];
    double usedArea = 0;
    if (err == null) {
      for (final p in all) {
        final w = p[0] + kerf, h = p[1] + kerf;
        bool placed = false;
        for (int s = 0; s < sheets.length && !placed; s++) {
          for (final shelf in sheets[s]) {
            if (h <= shelf[1] && shelf[2] + w <= sw + kerf) {
              shelf[2] += w;
              counts[s]++;
              placed = true;
              break;
            }
          }
          if (!placed) {
            final y = sheets[s].isEmpty ? 0.0 : sheets[s].last[0] + sheets[s].last[1];
            if (y + h <= sh + kerf) {
              sheets[s].add([y, h, w]);
              counts[s]++;
              placed = true;
            }
          }
        }
        if (!placed) {
          sheets.add([
            [0.0, h, w]
          ]);
          counts.add(1);
        }
        usedArea += p[0] * p[1];
      }
    }
    final waste = sheets.isEmpty ? 0.0 : (1 - usedArea / (sheets.length * sw * sh)) * 100;
    return Scaffold(
      appBar: AppBar(title: const Text('حساب الألواح'), backgroundColor: navy, foregroundColor: Colors.white),
      floatingActionButton:
          FloatingActionButton.extended(onPressed: () => edit(null), icon: const Icon(Icons.add), label: const Text('إضافة قطعة')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 90),
        children: [
          Text('اللوح: ${f(sw)} × ${f(sh)} سم  |  الديسك: ${f(setting('disc'))} ملم', textAlign: TextAlign.center),
          const SizedBox(height: 6),
          for (int i = 0; i < pieces.length; i++)
            Card(
              child: ListTile(
                onTap: () => edit(i),
                title: Text('${f(pieces[i][0])} × ${f(pieces[i][1])} سم  ×  ${f(pieces[i][2])}'),
                trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () {
                      setState(() => pieces.removeAt(i));
                      save();
                    }),
              ),
            ),
          if (err != null) Text(err, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          if (err == null && sheets.isNotEmpty) ...[
            const Divider(),
            Text('عدد الألواح: ${sheets.length}   |   الهدر: ${f(waste)}%',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            for (int s = 0; s < sheets.length; s++)
              Card(color: Colors.purple.shade50, child: ListTile(title: Text('لوح ${s + 1}: ${counts[s]} قطعة'))),
          ],
        ],
      ),
    );
  }
}

// ---------- الإعدادات ----------
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final ctrls = <String, TextEditingController>{};

  @override
  void initState() {
    super.initState();
    for (final k in settingDefs.keys) {
      ctrls[k] = TextEditingController(text: f(setting(k)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إعدادات الخصميات'), backgroundColor: navy, foregroundColor: Colors.white),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          for (final k in settingDefs.keys)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: TextField(
                controller: ctrls[k],
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: settingDefs[k]![0] as String, border: const OutlineInputBorder()),
                onChanged: (v) {
                  final n = num_(v);
                  if (n != null) prefs.setDouble('s_$k', n);
                },
              ),
            ),
          const Text('يتم الحفظ تلقائياً', textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
